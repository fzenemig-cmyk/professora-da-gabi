import type { StudyTheme } from "@/types";
import { VideoRecommendations } from "./VideoRecommendations";

type LessonPageProps = {
  theme: StudyTheme;
  onFlashcards: () => void;
  onPractice: () => void;
  onExam: () => void;
};

export function LessonPage({ theme, onFlashcards, onPractice, onExam }: LessonPageProps) {
  return (
    <section className="screen lesson-screen">
      <div className="lesson-header">
        <div>
          <p className="eyebrow">
            {theme.grade} · {theme.subject}
          </p>
          <h1>{theme.lessonTitle}</h1>
          <p className="lead">{theme.explanation}</p>
        </div>
        <figure>
          <img src={theme.image.src} alt={theme.image.alt} />
          <figcaption>{theme.image.credit}</figcaption>
        </figure>
      </div>

      <section className="section-band">
        <h2>Resumo</h2>
        <ul>
          {theme.summaryBullets.map((item) => (
            <li key={item}>{item}</li>
          ))}
        </ul>
      </section>

      <section className="section-band">
        <h2>Exemplo prático</h2>
        <p>{theme.practicalExample}</p>
      </section>

      <section className="section-band">
        <h2>Conceitos importantes</h2>
        <div className="tag-row">
          {theme.keyConcepts.map((item) => (
            <span key={item}>{item}</span>
          ))}
        </div>
      </section>

      <div className="action-row">
        <button onClick={onFlashcards}>Ver flashcards</button>
        <button onClick={onPractice}>Treinar este tema</button>
        <button onClick={onExam}>Criar prova deste tema</button>
      </div>

      <VideoRecommendations videos={theme.recommendedVideos} />
    </section>
  );
}
