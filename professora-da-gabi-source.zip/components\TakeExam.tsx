import { useState } from "react";
import type { AnswerRecord, PracticeQuestion, StudyTheme } from "@/types";
import { QuestionRenderer } from "./QuestionRenderer";

type TakeExamProps = {
  theme: StudyTheme;
  questions: PracticeQuestion[];
  onFinish: (answers: AnswerRecord[]) => void;
};

export function TakeExam({ theme, questions, onFinish }: TakeExamProps) {
  const [index, setIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const question = questions[index];

  if (!question) {
    return (
      <section className="screen narrow-screen">
        <h1>Não encontrei questões suficientes</h1>
        <p className="lead">Tente criar uma prova menor ou mudar os tipos escolhidos.</p>
      </section>
    );
  }

  function saveAnswer(value: string) {
    setAnswers((current) => ({ ...current, [question.id]: value }));
  }

  function finish() {
    onFinish(
      questions.map((item) => ({
        questionId: item.id,
        value: answers[item.id] ?? ""
      }))
    );
  }

  return (
    <section className="screen narrow-screen">
      <p className="eyebrow">
        Prova · {theme.subject} · {theme.topic}
      </p>
      <h1>Questão {index + 1}</h1>
      <article className="question-card">
        <small>
          {index + 1} de {questions.length} · {question.difficulty}
        </small>
        <h2>{question.prompt}</h2>
        <QuestionRenderer question={question} value={answers[question.id] ?? ""} onChange={saveAnswer} />
      </article>

      <div className="action-row">
        <button disabled={index === 0} onClick={() => setIndex((current) => current - 1)}>
          Anterior
        </button>
        {index < questions.length - 1 ? (
          <button onClick={() => setIndex((current) => current + 1)}>Próxima</button>
        ) : (
          <button onClick={finish}>Finalizar prova</button>
        )}
      </div>
    </section>
  );
}
