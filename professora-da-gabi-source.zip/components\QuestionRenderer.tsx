import type { PracticeQuestion } from "@/types";

type QuestionRendererProps = {
  question: PracticeQuestion;
  value: string;
  onChange: (value: string) => void;
  disabled?: boolean;
};

export function QuestionRenderer({ question, value, onChange, disabled }: QuestionRendererProps) {
  if (question.type === "multiple_choice" || question.type === "true_false") {
    return (
      <div className="option-list">
        {question.options?.map((option) => (
          <label key={option} className={value === option ? "selected-option" : ""}>
            <input
              type="radio"
              name={question.id}
              checked={value === option}
              disabled={disabled}
              onChange={() => onChange(option)}
            />
            {option}
          </label>
        ))}
      </div>
    );
  }

  if (question.type === "matching") {
    return (
      <div className="matching-box">
        {question.pairs?.map((pair) => (
          <p key={pair.left}>
            <strong>{pair.left}</strong> → {pair.right}
          </p>
        ))}
        <input
          value={value}
          disabled={disabled}
          onChange={(event) => onChange(event.target.value)}
          placeholder="Digite as relações em ordem"
        />
      </div>
    );
  }

  return (
    <textarea
      value={value}
      disabled={disabled}
      onChange={(event) => onChange(event.target.value)}
      placeholder={question.type === "complete" ? "Digite a palavra que completa" : "Escreva sua resposta"}
    />
  );
}
