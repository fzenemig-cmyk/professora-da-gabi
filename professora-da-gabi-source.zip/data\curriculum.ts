import type { StudyTheme } from "@/types";

const commonVideos = (topic: string) => [
  {
    title: `${topic}: explicação curta`,
    channel: "Canal educativo recomendado",
    description: "Vídeo indicado para revisar o tema com linguagem simples.",
    url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
    embedUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    duration: "6 min",
    level: "fácil" as const,
    status: "aprovado" as const
  },
  {
    title: `${topic}: exemplos resolvidos`,
    channel: "Aula aberta",
    description: "Sugestão para ver mais exemplos depois da leitura.",
    url: "https://www.youtube.com/watch?v=ysz5S6PUM-U",
    embedUrl: "https://www.youtube.com/embed/ysz5S6PUM-U",
    duration: "9 min",
    level: "médio" as const,
    status: "aprovado" as const
  }
];

export const curriculum: StudyTheme[] = [
  {
    grade: "5º ano",
    subject: "Matemática",
    topic: "Frações",
    lessonTitle: "Frações no dia a dia",
    explanation:
      "Fração é uma forma de representar partes de um inteiro. O número de cima mostra quantas partes usamos, e o número de baixo mostra em quantas partes iguais o inteiro foi dividido.",
    summaryBullets: [
      "O numerador fica em cima.",
      "O denominador fica embaixo.",
      "As partes precisam ter o mesmo tamanho.",
      "Frações aparecem em receitas, medidas e divisões."
    ],
    practicalExample:
      "Se uma pizza foi dividida em 4 pedaços iguais e Gabi comeu 1 pedaço, ela comeu 1/4 da pizza.",
    keyConcepts: ["numerador", "denominador", "partes iguais", "inteiro"],
    image: {
      src: "https://upload.wikimedia.org/wikipedia/commons/thumb/4/45/Pizza-3007395.jpg/640px-Pizza-3007395.jpg",
      alt: "Pizza cortada em partes",
      credit: "Imagem: Wikimedia Commons"
    },
    recommendedVideos: commonVideos("Frações"),
    flashcards: [
      {
        question: "O que é denominador?",
        shortAnswer: "É o número de baixo da fração.",
        explanation: "Ele indica em quantas partes iguais o inteiro foi dividido."
      },
      {
        question: "Em 3/5, qual é o numerador?",
        shortAnswer: "3."
      }
    ],
    practiceQuestions: [
      {
        id: "mat-frac-1",
        type: "multiple_choice",
        difficulty: "easy",
        prompt: "Em 1/4, qual número é o denominador?",
        options: ["1", "4", "5", "14", "0"],
        correctAnswer: "4",
        explanation: "O denominador é o número de baixo."
      },
      {
        id: "mat-frac-2",
        type: "true_false",
        difficulty: "easy",
        prompt: "Uma fração sempre representa partes de mesmo tamanho.",
        options: ["Verdadeiro", "Falso"],
        correctAnswer: "Verdadeiro",
        explanation: "Para ser fração de um inteiro, as partes devem ser iguais."
      },
      {
        id: "mat-frac-3",
        type: "complete",
        difficulty: "medium",
        prompt: "Complete: o número de cima da fração se chama ____.",
        correctAnswer: "numerador",
        explanation: "Numerador é o termo usado para o número de cima."
      },
      {
        id: "mat-frac-4",
        type: "open",
        difficulty: "medium",
        prompt: "Explique uma situação do dia a dia em que usamos frações.",
        correctAnswer: "Resposta pessoal.",
        explanation: "A resposta aberta será corrigida depois."
      },
      {
        id: "mat-frac-5",
        type: "matching",
        difficulty: "hard",
        prompt: "Relacione: numerador, denominador e inteiro.",
        pairs: [
          { left: "Numerador", right: "partes usadas" },
          { left: "Denominador", right: "partes totais" },
          { left: "Inteiro", right: "todo completo" }
        ],
        correctAnswer: "Numerador-partes usadas; Denominador-partes totais; Inteiro-todo completo",
        explanation: "Cada termo mostra uma função diferente na fração."
      }
    ]
  },
  {
    grade: "5º ano",
    subject: "Português",
    topic: "Sujeito e predicado",
    lessonTitle: "Quem faz e o que acontece",
    explanation:
      "Em uma oração, o sujeito indica de quem ou do que estamos falando. O predicado mostra o que acontece com esse sujeito.",
    summaryBullets: [
      "Sujeito é o termo principal sobre quem se fala.",
      "Predicado traz a ação ou informação.",
      "O verbo costuma aparecer no predicado.",
      "Perguntar 'quem?' ajuda a encontrar o sujeito."
    ],
    practicalExample: "Na frase 'A Gabi estudou Ciências', 'A Gabi' é sujeito e 'estudou Ciências' é predicado.",
    keyConcepts: ["oração", "sujeito", "predicado", "verbo"],
    image: {
      src: "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3f/Reading_book.jpg/640px-Reading_book.jpg",
      alt: "Pessoa lendo um livro",
      credit: "Imagem: Wikimedia Commons"
    },
    recommendedVideos: commonVideos("Sujeito e predicado"),
    flashcards: [
      { question: "O que é sujeito?", shortAnswer: "É sobre quem ou o que se fala." },
      { question: "Onde geralmente fica o verbo?", shortAnswer: "No predicado." }
    ],
    practiceQuestions: [
      {
        id: "por-suj-1",
        type: "multiple_choice",
        difficulty: "easy",
        prompt: "Na frase 'O cachorro correu', qual é o sujeito?",
        options: ["O cachorro", "correu", "cachorro correu", "O", "nenhum"],
        correctAnswer: "O cachorro",
        explanation: "Estamos falando do cachorro."
      },
      {
        id: "por-suj-2",
        type: "true_false",
        difficulty: "easy",
        prompt: "O predicado sempre traz alguma informação sobre o sujeito.",
        options: ["Verdadeiro", "Falso"],
        correctAnswer: "Verdadeiro",
        explanation: "Essa é a função do predicado."
      },
      {
        id: "por-suj-3",
        type: "complete",
        difficulty: "medium",
        prompt: "Complete: em 'As crianças brincaram', o predicado é ____.",
        correctAnswer: "brincaram",
        explanation: "O predicado informa a ação."
      },
      {
        id: "por-suj-4",
        type: "open",
        difficulty: "medium",
        prompt: "Crie uma frase e separe sujeito e predicado.",
        correctAnswer: "Resposta pessoal.",
        explanation: "A resposta aberta será corrigida depois."
      },
      {
        id: "por-suj-5",
        type: "matching",
        difficulty: "hard",
        prompt: "Relacione sujeito, predicado e verbo.",
        pairs: [
          { left: "Sujeito", right: "sobre quem se fala" },
          { left: "Predicado", right: "informação sobre o sujeito" },
          { left: "Verbo", right: "ação ou estado" }
        ],
        correctAnswer: "Sujeito-sobre quem se fala; Predicado-informação sobre o sujeito; Verbo-ação ou estado",
        explanation: "Esses termos ajudam a entender a estrutura da frase."
      }
    ]
  },
  {
    grade: "5º ano",
    subject: "Ciências",
    topic: "Sistema Solar",
    lessonTitle: "Conhecendo o Sistema Solar",
    explanation:
      "O Sistema Solar é formado pelo Sol, pelos planetas, luas, asteroides, cometas e outros corpos que giram ao seu redor por causa da gravidade.",
    summaryBullets: [
      "O Sol é uma estrela.",
      "A Terra é um planeta.",
      "Os planetas giram ao redor do Sol.",
      "A gravidade ajuda a manter os astros em órbita."
    ],
    practicalExample:
      "Quando observamos o dia e a noite, estamos vendo efeitos do movimento da Terra no espaço.",
    keyConcepts: ["Sol", "planetas", "órbita", "gravidade", "lua"],
    image: {
      src: "https://upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Planets2013.svg/640px-Planets2013.svg.png",
      alt: "Ilustração dos planetas do Sistema Solar",
      credit: "Imagem: Wikimedia Commons/NASA"
    },
    recommendedVideos: commonVideos("Sistema Solar"),
    flashcards: [
      { question: "O Sol é planeta ou estrela?", shortAnswer: "Estrela." },
      {
        question: "O que é órbita?",
        shortAnswer: "É o caminho que um astro faz ao redor de outro.",
        explanation: "A Terra, por exemplo, orbita o Sol."
      }
    ],
    practiceQuestions: [
      {
        id: "cie-sol-1",
        type: "multiple_choice",
        difficulty: "easy",
        prompt: "O Sol é:",
        options: ["uma estrela", "um planeta", "uma lua", "um cometa", "um satélite artificial"],
        correctAnswer: "uma estrela",
        explanation: "O Sol produz luz e calor como estrela."
      },
      {
        id: "cie-sol-2",
        type: "true_false",
        difficulty: "easy",
        prompt: "A Terra gira ao redor do Sol.",
        options: ["Verdadeiro", "Falso"],
        correctAnswer: "Verdadeiro",
        explanation: "Esse movimento se chama translação."
      },
      {
        id: "cie-sol-3",
        type: "complete",
        difficulty: "medium",
        prompt: "Complete: o caminho de um planeta ao redor do Sol se chama ____.",
        correctAnswer: "órbita",
        explanation: "Órbita é o caminho seguido no espaço."
      },
      {
        id: "cie-sol-4",
        type: "open",
        difficulty: "medium",
        prompt: "Explique por que o Sol é importante para a Terra.",
        correctAnswer: "Resposta pessoal.",
        explanation: "A resposta aberta será corrigida depois."
      },
      {
        id: "cie-sol-5",
        type: "matching",
        difficulty: "hard",
        prompt: "Relacione os conceitos.",
        pairs: [
          { left: "Sol", right: "estrela" },
          { left: "Terra", right: "planeta" },
          { left: "Lua", right: "satélite natural" }
        ],
        correctAnswer: "Sol-estrela; Terra-planeta; Lua-satélite natural",
        explanation: "Cada corpo celeste tem uma classificação."
      }
    ]
  },
  {
    grade: "5º ano",
    subject: "Geografia",
    topic: "Regiões do Brasil",
    lessonTitle: "As cinco regiões brasileiras",
    explanation:
      "O Brasil é dividido em cinco grandes regiões: Norte, Nordeste, Centro-Oeste, Sudeste e Sul. Essa divisão ajuda a estudar características naturais, sociais e econômicas.",
    summaryBullets: [
      "O Brasil tem cinco regiões.",
      "Cada região reúne vários estados.",
      "As regiões ajudam a organizar estudos e dados.",
      "Clima, relevo e cultura variam pelo território."
    ],
    practicalExample:
      "Ao comparar Norte e Sul, podemos perceber diferenças de clima, vegetação, população e costumes.",
    keyConcepts: ["região", "estado", "território", "mapa", "IBGE"],
    image: {
      src: "https://upload.wikimedia.org/wikipedia/commons/thumb/b/bc/Brazil_Regions.svg/640px-Brazil_Regions.svg.png",
      alt: "Mapa das regiões do Brasil",
      credit: "Imagem: Wikimedia Commons"
    },
    recommendedVideos: commonVideos("Regiões do Brasil"),
    flashcards: [
      { question: "Quantas regiões tem o Brasil?", shortAnswer: "Cinco." },
      { question: "Qual órgão organiza essa divisão regional?", shortAnswer: "IBGE." }
    ],
    practiceQuestions: [
      {
        id: "geo-reg-1",
        type: "multiple_choice",
        difficulty: "easy",
        prompt: "Qual é uma região do Brasil?",
        options: ["Nordeste", "Pacífico", "Andes", "Europa", "Saara"],
        correctAnswer: "Nordeste",
        explanation: "Nordeste é uma das cinco regiões brasileiras."
      },
      {
        id: "geo-reg-2",
        type: "true_false",
        difficulty: "easy",
        prompt: "O Brasil é dividido em cinco regiões.",
        options: ["Verdadeiro", "Falso"],
        correctAnswer: "Verdadeiro",
        explanation: "São Norte, Nordeste, Centro-Oeste, Sudeste e Sul."
      },
      {
        id: "geo-reg-3",
        type: "complete",
        difficulty: "medium",
        prompt: "Complete: a divisão regional ajuda a estudar o ____ brasileiro.",
        correctAnswer: "território",
        explanation: "A palavra território se refere ao espaço do país."
      },
      {
        id: "geo-reg-4",
        type: "open",
        difficulty: "medium",
        prompt: "Escolha uma região brasileira e cite uma característica dela.",
        correctAnswer: "Resposta pessoal.",
        explanation: "A resposta aberta será corrigida depois."
      },
      {
        id: "geo-reg-5",
        type: "matching",
        difficulty: "hard",
        prompt: "Relacione região e ideia principal.",
        pairs: [
          { left: "Região", right: "grupo de estados" },
          { left: "Estado", right: "unidade do país" },
          { left: "Mapa", right: "representação do espaço" }
        ],
        correctAnswer: "Região-grupo de estados; Estado-unidade do país; Mapa-representação do espaço",
        explanation: "Essas ideias aparecem juntas em Geografia."
      }
    ]
  },
  {
    grade: "5º ano",
    subject: "História",
    topic: "Brasil Colônia",
    lessonTitle: "Primeiros tempos do Brasil Colônia",
    explanation:
      "Brasil Colônia é o período em que o território brasileiro esteve sob domínio de Portugal. Esse período teve exploração de recursos, formação de vilas e muitos conflitos.",
    summaryBullets: [
      "Portugal colonizou o Brasil.",
      "O pau-brasil foi explorado no início.",
      "A cana-de-açúcar ganhou importância econômica.",
      "Povos indígenas resistiram de muitas formas."
    ],
    practicalExample:
      "Ao estudar uma cidade antiga, podemos encontrar marcas desse período na arquitetura, nos nomes de lugares e nas tradições.",
    keyConcepts: ["colônia", "metrópole", "povos indígenas", "exploração", "cana-de-açúcar"],
    image: {
      src: "https://upload.wikimedia.org/wikipedia/commons/thumb/1/10/Engenho_de_a%C3%A7ucar.jpg/640px-Engenho_de_a%C3%A7ucar.jpg",
      alt: "Ilustração histórica de engenho de açúcar",
      credit: "Imagem: Wikimedia Commons"
    },
    recommendedVideos: commonVideos("Brasil Colônia"),
    flashcards: [
      { question: "Quem colonizou o Brasil?", shortAnswer: "Portugal." },
      { question: "O que era a metrópole?", shortAnswer: "O país que controlava a colônia." }
    ],
    practiceQuestions: [
      {
        id: "his-col-1",
        type: "multiple_choice",
        difficulty: "easy",
        prompt: "No período colonial, o Brasil era controlado por:",
        options: ["Portugal", "Argentina", "França", "Estados Unidos", "Espanha"],
        correctAnswer: "Portugal",
        explanation: "Portugal era a metrópole."
      },
      {
        id: "his-col-2",
        type: "true_false",
        difficulty: "easy",
        prompt: "Povos indígenas já viviam no território antes da colonização portuguesa.",
        options: ["Verdadeiro", "Falso"],
        correctAnswer: "Verdadeiro",
        explanation: "Havia muitos povos indígenas com culturas diversas."
      },
      {
        id: "his-col-3",
        type: "complete",
        difficulty: "medium",
        prompt: "Complete: o país que controla uma colônia é chamado de ____.",
        correctAnswer: "metrópole",
        explanation: "Metrópole é o termo histórico usado nesse contexto."
      },
      {
        id: "his-col-4",
        type: "open",
        difficulty: "medium",
        prompt: "Cite uma consequência da colonização para os povos indígenas.",
        correctAnswer: "Resposta pessoal.",
        explanation: "A resposta aberta será corrigida depois."
      },
      {
        id: "his-col-5",
        type: "matching",
        difficulty: "hard",
        prompt: "Relacione os termos.",
        pairs: [
          { left: "Colônia", right: "território dominado" },
          { left: "Metrópole", right: "país dominador" },
          { left: "Pau-brasil", right: "recurso explorado" }
        ],
        correctAnswer: "Colônia-território dominado; Metrópole-país dominador; Pau-brasil-recurso explorado",
        explanation: "Esses termos ajudam a entender o período colonial."
      }
    ]
  },
  {
    grade: "5º ano",
    subject: "Inglês",
    topic: "Verbo to be",
    lessonTitle: "Usando am, is e are",
    explanation:
      "O verbo to be pode significar ser ou estar. No presente, usamos am com I, is com he, she e it, e are com you, we e they.",
    summaryBullets: [
      "I am significa eu sou ou eu estou.",
      "He, she e it usam is.",
      "You, we e they usam are.",
      "O verbo muda conforme a pessoa."
    ],
    practicalExample: "I am happy significa 'Eu estou feliz'. She is a student significa 'Ela é estudante'.",
    keyConcepts: ["I am", "you are", "he is", "she is", "they are"],
    image: {
      src: "https://upload.wikimedia.org/wikipedia/commons/thumb/8/8a/English_Language_Word_Cloud.png/640px-English_Language_Word_Cloud.png",
      alt: "Nuvem de palavras em inglês",
      credit: "Imagem: Wikimedia Commons"
    },
    recommendedVideos: commonVideos("Verbo to be"),
    flashcards: [
      { question: "Qual forma acompanha I?", shortAnswer: "am." },
      { question: "Qual forma acompanha they?", shortAnswer: "are." }
    ],
    practiceQuestions: [
      {
        id: "ing-be-1",
        type: "multiple_choice",
        difficulty: "easy",
        prompt: "Complete: I ____ Gabi.",
        options: ["am", "is", "are", "be", "has"],
        correctAnswer: "am",
        explanation: "Com I usamos am."
      },
      {
        id: "ing-be-2",
        type: "true_false",
        difficulty: "easy",
        prompt: "Com she usamos is.",
        options: ["Verdadeiro", "Falso"],
        correctAnswer: "Verdadeiro",
        explanation: "She is é a forma correta."
      },
      {
        id: "ing-be-3",
        type: "complete",
        difficulty: "medium",
        prompt: "Complete: They ____ friends.",
        correctAnswer: "are",
        explanation: "Com they usamos are."
      },
      {
        id: "ing-be-4",
        type: "open",
        difficulty: "medium",
        prompt: "Escreva uma frase simples usando am, is ou are.",
        correctAnswer: "Resposta pessoal.",
        explanation: "A resposta aberta será corrigida depois."
      },
      {
        id: "ing-be-5",
        type: "matching",
        difficulty: "hard",
        prompt: "Relacione pronome e forma do to be.",
        pairs: [
          { left: "I", right: "am" },
          { left: "She", right: "is" },
          { left: "They", right: "are" }
        ],
        correctAnswer: "I-am; She-is; They-are",
        explanation: "Cada pronome combina com uma forma."
      }
    ]
  }
];
