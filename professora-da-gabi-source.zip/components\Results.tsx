import type { ExamResult } from "@/types";

type ResultsProps = {
  result: ExamResult;
  onReviewMistakes: () => void;
  onNewExam: () => void;
};

export function Results({ result, onReviewMistakes, onNewExam }: ResultsProps) {
  return (
    <section className="screen">
      <p className="eyebrow">
        Resultado · {result.subject} · {result.topic}
      </p>
      <h1>Nota: {result.score}%</h1>

      <div className="stats-grid">
        <div>
          <strong>{result.correctCount}</strong>
          <span>acertos</span>
        </div>
        <div>
          <strong>{result.wrongCount}</strong>
          <span>erros</span>
        </div>
        <div>
          <strong>{result.pendingOpenCount}</strong>
          <span>pendentes</span>
        </div>
      </div>

      <section className="section-band">
        <h2>Correção</h2>
        <div className="answer-list">
          {result.answers.map((answer) => (
            <article key={answer.questionId} className="answer-card">
              <strong>{answer.prompt}</strong>
              <p>Sua resposta: {answer.value || "em branco"}</p>
              <p>
                {answer.correct === null
                  ? "Pendente de correção."
                  : answer.correct
                    ? "Correta."
                    : `Correta seria: ${answer.correctAnswer}.`}
              </p>
              <small>{answer.explanation}</small>
            </article>
          ))}
        </div>
      </section>

      <div className="action-row">
        <button onClick={onReviewMistakes}>Revisar erros</button>
        <button onClick={onNewExam}>Criar outra prova</button>
      </div>
    </section>
  );
}
