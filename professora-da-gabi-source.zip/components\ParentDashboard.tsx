import type { Activity, ExamResult, StudyTheme } from "@/types";

type ParentDashboardProps = {
  results: ExamResult[];
  activities: Activity[];
  themes: StudyTheme[];
};

function mostCommon(values: string[]) {
  const counts = values.reduce<Record<string, number>>((acc, value) => {
    acc[value] = (acc[value] ?? 0) + 1;
    return acc;
  }, {});
  return Object.entries(counts).sort((a, b) => b[1] - a[1])[0]?.[0] ?? "Ainda sem dados";
}

export function ParentDashboard({ results, activities, themes }: ParentDashboardProps) {
  const average = results.length
    ? Math.round(results.reduce((sum, item) => sum + item.score, 0) / results.length)
    : 0;
  const wrongAnswers = results.flatMap((result) =>
    result.answers
      .filter((answer) => answer.correct === false)
      .map((answer) => ({ ...answer, subject: result.subject, topic: result.topic }))
  );
  const studiedSubjects = Array.from(new Set(activities.map((activity) => activity.subject)));
  const studiedTopics = Array.from(new Set(activities.map((activity) => activity.topic)));
  const nextTheme =
    themes.find((theme) => !studiedTopics.includes(theme.topic)) ?? themes[0];

  return (
    <section className="screen">
      <h1>Área dos pais</h1>

      <div className="stats-grid">
        <div>
          <strong>{results.length}</strong>
          <span>provas realizadas</span>
        </div>
        <div>
          <strong>{average}%</strong>
          <span>média geral</span>
        </div>
        <div>
          <strong>{studiedSubjects.length}</strong>
          <span>matérias estudadas</span>
        </div>
      </div>

      <section className="section-band">
        <h2>Resumo</h2>
        <p>Temas estudados: {studiedTopics.length ? studiedTopics.join(", ") : "ainda nenhum"}</p>
        <p>Tema com mais erro: {mostCommon(wrongAnswers.map((item) => item.topic))}</p>
        <p>Matéria com mais dificuldade: {mostCommon(wrongAnswers.map((item) => item.subject))}</p>
        <p>Sugestão do próximo estudo: {nextTheme.subject} · {nextTheme.topic}</p>
      </section>

      <section className="section-band">
        <h2>Últimas atividades</h2>
        {activities.length === 0 ? (
          <p>Nenhuma atividade registrada ainda.</p>
        ) : (
          <div className="answer-list">
            {activities.slice(0, 8).map((activity) => (
              <article className="answer-card" key={activity.id}>
                <strong>{activity.label}</strong>
                <small>{new Date(activity.createdAt).toLocaleString("pt-BR")}</small>
              </article>
            ))}
          </div>
        )}
      </section>
    </section>
  );
}
