import { useMemo, useState } from "react";
import type { StudyTheme } from "@/types";

type StudySelectorProps = {
  grades: string[];
  themes: StudyTheme[];
  onChooseTheme: (theme: StudyTheme) => void;
};

export function StudySelector({ grades, themes, onChooseTheme }: StudySelectorProps) {
  const [grade, setGrade] = useState(grades[0] ?? "");
  const subjects = useMemo(
    () => Array.from(new Set(themes.filter((item) => item.grade === grade).map((item) => item.subject))),
    [grade, themes]
  );
  const [subject, setSubject] = useState(subjects[0] ?? "Ciências");

  const topics = themes.filter((item) => item.grade === grade && item.subject === subject);

  function updateGrade(nextGrade: string) {
    setGrade(nextGrade);
    const nextSubject = themes.find((item) => item.grade === nextGrade)?.subject ?? "";
    setSubject(nextSubject);
  }

  return (
    <section className="screen">
      <h1>Escolher estudo</h1>
      <div className="form-grid">
        <label>
          Ano escolar
          <select value={grade} onChange={(event) => updateGrade(event.target.value)}>
            {grades.map((item) => (
              <option key={item}>{item}</option>
            ))}
          </select>
        </label>

        <label>
          Matéria
          <select value={subject} onChange={(event) => setSubject(event.target.value)}>
            {subjects.map((item) => (
              <option key={item}>{item}</option>
            ))}
          </select>
        </label>
      </div>

      <div className="card-grid">
        {topics.map((theme) => (
          <button className="study-card" key={theme.topic} onClick={() => onChooseTheme(theme)}>
            <span>{theme.subject}</span>
            <strong>{theme.topic}</strong>
            <small>{theme.lessonTitle}</small>
          </button>
        ))}
      </div>
    </section>
  );
}
