import { useState } from "react";
import type { StudyTheme } from "@/types";
import { QuestionRenderer } from "./QuestionRenderer";

type PracticeModeProps = {
  theme: StudyTheme;
  onChangeTheme: () => void;
  onFinish: () => void;
};

export function PracticeMode({ theme, onChangeTheme, onFinish }: PracticeModeProps) {
  const [index, setIndex] = useState(0);
  const [value, setValue] = useState("");
  const [feedback, setFeedback] = useState<null | { correct: boolean; text: string }>(null);
  const questions = theme.practiceQuestions.filter((question) => question.type !== "open");
  const question = questions[index];

  function answer() {
    const correct =
      value.trim().toLowerCase() === String(question.correctAnswer).trim().toLowerCase();
    setFeedback({
      correct,
      text: `${correct ? "Acertou!" : "Ainda não."} Resposta correta: ${question.correctAnswer}. ${question.explanation}`
    });
    onFinish();
  }

  function next() {
    setIndex((current) => (current + 1) % questions.length);
    setValue("");
    setFeedback(null);
  }

  return (
    <section className="screen narrow-screen">
      <p className="eyebrow">
        Treino guiado · {theme.subject}
      </p>
      <h1>{theme.topic}</h1>
      <button className="link-button" onClick={onChangeTheme}>
        Escolher outro tema
      </button>

      <article className="question-card">
        <small>
          Questão {index + 1} de {questions.length}
        </small>
        <h2>{question.prompt}</h2>
        <QuestionRenderer
          question={question}
          value={value}
          onChange={setValue}
          disabled={feedback !== null}
        />
        {feedback ? (
          <div className={feedback.correct ? "feedback success" : "feedback error"}>{feedback.text}</div>
        ) : (
          <button onClick={answer} disabled={!value.trim()}>
            Responder
          </button>
        )}
        {feedback && <button onClick={next}>Próxima questão</button>}
      </article>
    </section>
  );
}
