import type { Video } from "@/types";

export function VideoRecommendations({ videos }: { videos: Video[] }) {
  return (
    <section className="section-band">
      <h2>Vídeos para aprender melhor</h2>
      <div className="video-grid">
        {videos.map((video) => (
          <article className="video-card" key={video.title}>
            <iframe title={video.title} src={video.embedUrl} allowFullScreen />
            <div>
              <h3>{video.title}</h3>
              <p>{video.channel}</p>
              <small>
                {video.duration} · {video.level} · {video.status}
              </small>
              <p>{video.description}</p>
              <a href={video.url} target="_blank" rel="noreferrer">
                Abrir no YouTube
              </a>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
