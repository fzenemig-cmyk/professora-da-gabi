import { useMemo, useState } from "react";
import type { ExamConfig, QuestionType, StudyTheme } from "@/types";

const questionTypes: { key: QuestionType; label: string }[] = [
  { key: "multiple_choice", label: "Múltipla escolha" },
  { key: "true_false", label: "Verdadeiro ou falso" },
  { key: "open", label: "Pergunta aberta" },
  { key: "complete", label: "Complete a frase" },
  { key: "matching", label: "Relacione as colunas" }
];

type CreateExamProps = {
  themes: StudyTheme[];
  initialConfig: ExamConfig;
  onStartExam: (config: ExamConfig) => void;
};

export function CreateExam({ themes, initialConfig, onStartExam }: CreateExamProps) {
  const [config, setConfig] = useState<ExamConfig>(initialConfig);

  const subjects = useMemo(
    () => Array.from(new Set(themes.filter((item) => item.grade === config.grade).map((item) => item.subject))),
    [config.grade, themes]
  );
  const topics = themes.filter((item) => item.grade === config.grade && item.subject === config.subject);
  const difficultySum = config.easyCount + config.mediumCount + config.hardCount;
  const typeSum = Object.values(config.typeCounts).reduce((sum, count) => sum + count, 0);
  const errors = [
    difficultySum !== config.totalQuestions ? "A soma das dificuldades precisa bater com o total." : "",
    typeSum !== config.totalQuestions ? "A soma dos tipos precisa bater com o total." : "",
    config.typeCounts.multiple_choice > 0 && !config.multipleChoiceAlternatives
      ? "Escolha a quantidade de alternativas."
      : ""
  ].filter(Boolean);

  function updateNumber(key: keyof ExamConfig, value: string) {
    setConfig((current) => ({ ...current, [key]: Number(value) }));
  }

  return (
    <section className="screen">
      <h1>Criar prova</h1>

      <div className="form-grid">
        <label>
          Ano escolar
          <select
            value={config.grade}
            onChange={(event) => {
              const grade = event.target.value;
              const firstTheme = themes.find((item) => item.grade === grade) ?? themes[0];
              setConfig((current) => ({
                ...current,
                grade,
                subject: firstTheme.subject,
                topic: firstTheme.topic
              }));
            }}
          >
            {Array.from(new Set(themes.map((item) => item.grade))).map((grade) => (
              <option key={grade}>{grade}</option>
            ))}
          </select>
        </label>

        <label>
          Matéria
          <select
            value={config.subject}
            onChange={(event) => {
              const subject = event.target.value;
              const topic = themes.find(
                (item) => item.grade === config.grade && item.subject === subject
              )?.topic;
              setConfig((current) => ({ ...current, subject, topic: topic ?? current.topic }));
            }}
          >
            {subjects.map((subject) => (
              <option key={subject}>{subject}</option>
            ))}
          </select>
        </label>

        <label>
          Tema
          <select
            value={config.topic}
            onChange={(event) => setConfig((current) => ({ ...current, topic: event.target.value }))}
          >
            {topics.map((theme) => (
              <option key={theme.topic}>{theme.topic}</option>
            ))}
          </select>
        </label>

        <label>
          Total de questões
          <input
            type="number"
            min="1"
            max="10"
            value={config.totalQuestions}
            onChange={(event) => updateNumber("totalQuestions", event.target.value)}
          />
        </label>
      </div>

      <section className="section-band">
        <h2>Dificuldades</h2>
        <div className="form-grid compact">
          <label>
            Fáceis
            <input type="number" min="0" value={config.easyCount} onChange={(event) => updateNumber("easyCount", event.target.value)} />
          </label>
          <label>
            Médias
            <input type="number" min="0" value={config.mediumCount} onChange={(event) => updateNumber("mediumCount", event.target.value)} />
          </label>
          <label>
            Difíceis
            <input type="number" min="0" value={config.hardCount} onChange={(event) => updateNumber("hardCount", event.target.value)} />
          </label>
        </div>
      </section>

      <section className="section-band">
        <h2>Tipos de questão</h2>
        <div className="form-grid compact">
          {questionTypes.map((type) => (
            <label key={type.key}>
              {type.label}
              <input
                type="number"
                min="0"
                value={config.typeCounts[type.key]}
                onChange={(event) =>
                  setConfig((current) => ({
                    ...current,
                    typeCounts: { ...current.typeCounts, [type.key]: Number(event.target.value) }
                  }))
                }
              />
            </label>
          ))}
          <label>
            Alternativas
            <select
              value={config.multipleChoiceAlternatives}
              onChange={(event) =>
                setConfig((current) => ({
                  ...current,
                  multipleChoiceAlternatives: Number(event.target.value) as 3 | 4 | 5
                }))
              }
            >
              <option value={3}>3</option>
              <option value={4}>4</option>
              <option value={5}>5</option>
            </select>
          </label>
        </div>
      </section>

      {errors.length > 0 && (
        <div className="feedback error">
          {errors.map((error) => (
            <p key={error}>{error}</p>
          ))}
        </div>
      )}

      <button disabled={errors.length > 0} onClick={() => onStartExam(config)}>
        Começar prova
      </button>
    </section>
  );
}
