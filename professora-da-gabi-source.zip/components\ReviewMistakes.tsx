import { useMemo, useState } from "react";
import type { ExamResult, StudyTheme } from "@/types";
import { QuestionRenderer } from "./QuestionRenderer";

type ReviewMistakesProps = {
  mistakes: ExamResult["answers"];
  themes: StudyTheme[];
  onClear: () => void;
};

export function ReviewMistakes({ mistakes, themes, onClear }: ReviewMistakesProps) {
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [checked, setChecked] = useState<Record<string, boolean>>({});
  const mistakeQuestions = useMemo(
    () =>
      mistakes
        .map((mistake) => {
          const question = themes
            .flatMap((theme) => theme.practiceQuestions)
            .find((item) => item.id === mistake.questionId);
          return question ? { mistake, question } : null;
        })
        .filter(Boolean),
    [mistakes, themes]
  );

  return (
    <section className="screen">
      <h1>Revisar erros</h1>
      {mistakeQuestions.length === 0 ? (
        <p className="lead">Ainda não há erros salvos.</p>
      ) : (
        <>
          <div className="answer-list">
            {mistakeQuestions.map((item) => {
              if (!item) return null;
              const value = answers[item.question.id] ?? "";
              const isChecked = checked[item.question.id];
              const correct =
                value.trim().toLowerCase() ===
                String(item.question.correctAnswer).trim().toLowerCase();

              return (
                <article className="question-card" key={item.question.id}>
                  <h2>{item.question.prompt}</h2>
                  <QuestionRenderer
                    question={item.question}
                    value={value}
                    disabled={isChecked}
                    onChange={(next) => setAnswers((current) => ({ ...current, [item.question.id]: next }))}
                  />
                  {!isChecked ? (
                    <button
                      disabled={!value.trim()}
                      onClick={() => setChecked((current) => ({ ...current, [item.question.id]: true }))}
                    >
                      Conferir
                    </button>
                  ) : (
                    <div className={correct ? "feedback success" : "feedback error"}>
                      {correct ? "Agora acertou." : `Resposta correta: ${item.question.correctAnswer}.`}{" "}
                      {item.question.explanation}
                    </div>
                  )}
                </article>
              );
            })}
          </div>
          <button className="link-button" onClick={onClear}>
            Limpar erros salvos
          </button>
        </>
      )}
    </section>
  );
}
