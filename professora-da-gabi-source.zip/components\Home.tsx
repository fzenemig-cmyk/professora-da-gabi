type HomeProps = {
  onStudy: () => void;
  onPractice: () => void;
  onCreateExam: () => void;
  onMistakes: () => void;
  onParents: () => void;
};

type HomeIconName = "book" | "target" | "exam" | "review" | "parents";

function HomeIcon({ name }: { name: HomeIconName }) {
  const paths: Record<HomeIconName, React.ReactNode> = {
    book: (
      <>
        <path d="M5 5.5C5 4.7 5.7 4 6.5 4H20v15H6.5C5.7 19 5 18.3 5 17.5z" />
        <path d="M5 17.5C5 16.7 5.7 16 6.5 16H20" />
      </>
    ),
    target: (
      <>
        <circle cx="12" cy="12" r="7" />
        <circle cx="12" cy="12" r="3" />
        <path d="M12 2v3M12 19v3M2 12h3M19 12h3" />
      </>
    ),
    exam: (
      <>
        <path d="M7 3h8l4 4v14H7z" />
        <path d="M15 3v5h5" />
        <path d="M9 12h7M9 16h5" />
      </>
    ),
    review: (
      <>
        <path d="M4 12a8 8 0 0 1 13.6-5.7" />
        <path d="M18 3v5h-5" />
        <path d="M20 12a8 8 0 0 1-13.6 5.7" />
        <path d="M6 21v-5h5" />
      </>
    ),
    parents: (
      <>
        <circle cx="9" cy="8" r="3" />
        <circle cx="17" cy="9" r="2.5" />
        <path d="M3.5 20a5.5 5.5 0 0 1 11 0" />
        <path d="M14 20a4.5 4.5 0 0 1 7 0" />
      </>
    )
  };

  return (
    <svg className="home-icon" viewBox="0 0 24 24" aria-hidden="true">
      {paths[name]}
    </svg>
  );
}

export function Home({ onStudy, onPractice, onCreateExam, onMistakes, onParents }: HomeProps) {
  return (
    <section className="screen home-screen">
      <div>
        <p className="eyebrow">Plataforma de estudos</p>
        <h1>Olá, Gabi!</h1>
        <p className="lead">Escolha o que quer fazer agora.</p>
      </div>

      <div className="action-grid">
        <button className="home-action" onClick={onStudy}>
          <HomeIcon name="book" />
          <span>Estudar</span>
        </button>
        <button className="home-action" onClick={onPractice}>
          <HomeIcon name="target" />
          <span>Treinar</span>
        </button>
        <button className="home-action" onClick={onCreateExam}>
          <HomeIcon name="exam" />
          <span>Criar prova</span>
        </button>
        <button className="home-action" onClick={onMistakes}>
          <HomeIcon name="review" />
          <span>Revisar erros</span>
        </button>
        <button className="home-action" onClick={onParents}>
          <HomeIcon name="parents" />
          <span>Área dos pais</span>
        </button>
      </div>
    </section>
  );
}
