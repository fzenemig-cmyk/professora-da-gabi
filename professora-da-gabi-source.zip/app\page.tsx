"use client";

import { useEffect, useMemo, useState } from "react";
import { curriculum } from "@/data/curriculum";
import type {
  Activity,
  AnswerRecord,
  ExamConfig,
  ExamResult,
  PracticeQuestion,
  QuestionType,
  StudyTheme
} from "@/types";
import {
  CreateExam,
  Flashcards,
  Home,
  LessonPage,
  ParentDashboard,
  PracticeMode,
  Results,
  ReviewMistakes,
  StudySelector,
  TakeExam
} from "@/components";

type View =
  | "home"
  | "selector"
  | "lesson"
  | "flashcards"
  | "practice"
  | "create-exam"
  | "take-exam"
  | "results"
  | "mistakes"
  | "parents";

const STORAGE_KEYS = {
  results: "gabi.examResults",
  mistakes: "gabi.mistakes",
  activities: "gabi.activities"
};

const emptyExam: ExamConfig = {
  grade: "5º ano",
  subject: "Ciências",
  topic: "Sistema Solar",
  totalQuestions: 5,
  easyCount: 2,
  mediumCount: 2,
  hardCount: 1,
  typeCounts: {
    multiple_choice: 2,
    true_false: 1,
    open: 1,
    complete: 1,
    matching: 0
  },
  multipleChoiceAlternatives: 4
};

function readLocal<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const value = window.localStorage.getItem(key);
    return value ? (JSON.parse(value) as T) : fallback;
  } catch {
    return fallback;
  }
}

function writeLocal<T>(key: string, value: T) {
  if (typeof window !== "undefined") {
    window.localStorage.setItem(key, JSON.stringify(value));
  }
}

function pickTheme(grade: string, subject: string, topic: string) {
  return (
    curriculum.find(
      (item) => item.grade === grade && item.subject === subject && item.topic === topic
    ) ?? curriculum[0]
  );
}

function buildExamQuestions(theme: StudyTheme, config: ExamConfig): PracticeQuestion[] {
  const selected: PracticeQuestion[] = [];
  const remainingByType: Record<QuestionType, number> = { ...config.typeCounts };
  const remainingByDifficulty = {
    easy: config.easyCount,
    medium: config.mediumCount,
    hard: config.hardCount
  };

  for (const question of theme.practiceQuestions) {
    if (selected.length >= config.totalQuestions) break;
    if (remainingByType[question.type] <= 0) continue;
    if (remainingByDifficulty[question.difficulty] <= 0) continue;

    const options =
      question.type === "multiple_choice" && question.options
        ? question.options.slice(0, config.multipleChoiceAlternatives)
        : question.options;

    selected.push({ ...question, options });
    remainingByType[question.type] -= 1;
    remainingByDifficulty[question.difficulty] -= 1;
  }

  return selected;
}

function scoreAnswers(theme: StudyTheme, answers: AnswerRecord[]): ExamResult {
  const now = new Date().toISOString();
  const scored = answers.map((answer) => {
    const question = theme.practiceQuestions.find((item) => item.id === answer.questionId);
    const isOpen = question?.type === "open";
    const correct =
      isOpen || !question
        ? null
        : String(answer.value).trim().toLowerCase() ===
          String(question.correctAnswer).trim().toLowerCase();

    return {
      ...answer,
      correct,
      explanation: question?.explanation ?? "",
      correctAnswer: question?.correctAnswer ?? "",
      prompt: question?.prompt ?? "",
      type: question?.type ?? "open"
    };
  });

  const closed = scored.filter((item) => item.correct !== null);
  const correctCount = closed.filter((item) => item.correct).length;
  const wrongCount = closed.filter((item) => item.correct === false).length;

  return {
    id: crypto.randomUUID(),
    createdAt: now,
    grade: theme.grade,
    subject: theme.subject,
    topic: theme.topic,
    totalClosedQuestions: closed.length,
    correctCount,
    wrongCount,
    pendingOpenCount: scored.filter((item) => item.correct === null).length,
    score: closed.length ? Math.round((correctCount / closed.length) * 100) : 0,
    answers: scored
  };
}

export default function App() {
  const [view, setView] = useState<View>("home");
  const [selectedTheme, setSelectedTheme] = useState<StudyTheme>(curriculum[2]);
  const [examConfig, setExamConfig] = useState<ExamConfig>(emptyExam);
  const [examQuestions, setExamQuestions] = useState<PracticeQuestion[]>([]);
  const [latestResult, setLatestResult] = useState<ExamResult | null>(null);
  const [results, setResults] = useState<ExamResult[]>([]);
  const [mistakes, setMistakes] = useState<ExamResult["answers"]>([]);
  const [activities, setActivities] = useState<Activity[]>([]);

  useEffect(() => {
    setResults(readLocal<ExamResult[]>(STORAGE_KEYS.results, []));
    setMistakes(readLocal<ExamResult["answers"]>(STORAGE_KEYS.mistakes, []));
    setActivities(readLocal<Activity[]>(STORAGE_KEYS.activities, []));
  }, []);

  const availableGrades = useMemo(
    () => Array.from(new Set(curriculum.map((item) => item.grade))),
    []
  );

  function addActivity(activity: Omit<Activity, "id" | "createdAt">) {
    const next = [
      {
        ...activity,
        id: crypto.randomUUID(),
        createdAt: new Date().toISOString()
      },
      ...activities
    ].slice(0, 20);

    setActivities(next);
    writeLocal(STORAGE_KEYS.activities, next);
  }

  function saveResult(result: ExamResult) {
    const nextResults = [result, ...results];
    const newMistakes = result.answers.filter((answer) => answer.correct === false);
    const nextMistakes = [...newMistakes, ...mistakes];

    setResults(nextResults);
    setMistakes(nextMistakes);
    setLatestResult(result);
    writeLocal(STORAGE_KEYS.results, nextResults);
    writeLocal(STORAGE_KEYS.mistakes, nextMistakes);
    addActivity({
      label: `Prova de ${result.topic}`,
      subject: result.subject,
      topic: result.topic
    });
    setView("results");
  }

  function startExam(config: ExamConfig) {
    const theme = pickTheme(config.grade, config.subject, config.topic);
    const questions = buildExamQuestions(theme, config);
    setSelectedTheme(theme);
    setExamConfig(config);
    setExamQuestions(questions);
    setView("take-exam");
  }

  function finishExam(answers: AnswerRecord[]) {
    saveResult(scoreAnswers(selectedTheme, answers));
  }

  function chooseTheme(theme: StudyTheme) {
    setSelectedTheme(theme);
    addActivity({
      label: `Aula estudada: ${theme.topic}`,
      subject: theme.subject,
      topic: theme.topic
    });
    setView("lesson");
  }

  function startThemeExam(theme = selectedTheme) {
    const config = {
      ...emptyExam,
      grade: theme.grade,
      subject: theme.subject,
      topic: theme.topic
    };
    startExam(config);
  }

  return (
    <main className="app-shell">
      {view !== "home" && (
        <button className="link-button top-back" onClick={() => setView("home")}>
          Voltar ao início
        </button>
      )}

      {view === "home" && (
        <Home
          onStudy={() => setView("selector")}
          onPractice={() => setView("practice")}
          onCreateExam={() => setView("create-exam")}
          onMistakes={() => setView("mistakes")}
          onParents={() => setView("parents")}
        />
      )}

      {view === "selector" && (
        <StudySelector grades={availableGrades} themes={curriculum} onChooseTheme={chooseTheme} />
      )}

      {view === "lesson" && (
        <LessonPage
          theme={selectedTheme}
          onFlashcards={() => setView("flashcards")}
          onPractice={() => setView("practice")}
          onExam={() => startThemeExam()}
        />
      )}

      {view === "flashcards" && (
        <Flashcards theme={selectedTheme} onBack={() => setView("lesson")} />
      )}

      {view === "practice" && (
        <PracticeMode
          theme={selectedTheme}
          onChangeTheme={() => setView("selector")}
          onFinish={() =>
            addActivity({
              label: `Treino guiado: ${selectedTheme.topic}`,
              subject: selectedTheme.subject,
              topic: selectedTheme.topic
            })
          }
        />
      )}

      {view === "create-exam" && (
        <CreateExam themes={curriculum} initialConfig={examConfig} onStartExam={startExam} />
      )}

      {view === "take-exam" && (
        <TakeExam theme={selectedTheme} questions={examQuestions} onFinish={finishExam} />
      )}

      {view === "results" && latestResult && (
        <Results
          result={latestResult}
          onReviewMistakes={() => setView("mistakes")}
          onNewExam={() => setView("create-exam")}
        />
      )}

      {view === "mistakes" && (
        <ReviewMistakes
          mistakes={mistakes}
          themes={curriculum}
          onClear={() => {
            setMistakes([]);
            writeLocal(STORAGE_KEYS.mistakes, []);
          }}
        />
      )}

      {view === "parents" && (
        <ParentDashboard results={results} activities={activities} themes={curriculum} />
      )}
    </main>
  );
}
