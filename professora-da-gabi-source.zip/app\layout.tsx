import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Professora da Gabi",
  description: "Plataforma simples de estudos com aulas, treino, provas e revisão."
};

export default function RootLayout({
  children
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR">
      <body>{children}</body>
    </html>
  );
}
