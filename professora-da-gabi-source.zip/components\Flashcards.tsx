import { useState } from "react";
import type { StudyTheme } from "@/types";

export function Flashcards({ theme, onBack }: { theme: StudyTheme; onBack: () => void }) {
  const [index, setIndex] = useState(0);
  const [showAnswer, setShowAnswer] = useState(false);
  const card = theme.flashcards[index];

  return (
    <section className="screen narrow-screen">
      <h1>Flashcards</h1>
      <p className="lead">{theme.topic}</p>

      <article className="flashcard" onClick={() => setShowAnswer(!showAnswer)}>
        <span>{showAnswer ? "Resposta" : "Pergunta"}</span>
        <h2>{showAnswer ? card.shortAnswer : card.question}</h2>
        {showAnswer && card.explanation && <p>{card.explanation}</p>}
      </article>

      <div className="action-row">
        <button
          onClick={() => {
            setIndex((current) => Math.max(0, current - 1));
            setShowAnswer(false);
          }}
        >
          Anterior
        </button>
        <button onClick={() => setShowAnswer(!showAnswer)}>Virar</button>
        <button
          onClick={() => {
            setIndex((current) => Math.min(theme.flashcards.length - 1, current + 1));
            setShowAnswer(false);
          }}
        >
          Próximo
        </button>
      </div>
      <button className="link-button" onClick={onBack}>
        Voltar para aula
      </button>
    </section>
  );
}
